package com.xingfu.access.rest.param.credphoto;

import java.util.List;

import com.xingfu.access.pojo.credphoto.Certificate;

/**
 * 多证上传图片和证件参数实体
 * 
 * @author zhangx
 *
 */
public class CredPhotoMultiSubmitParam {

	/**
	 * 用户id
	 */
	private long userId;

	/**
	 * 相册id（云相册）
	 */
	private long albumId;

	/**
	 * 原图id（云相册）
	 */
	private long photoId;

	/**
	 * 裁剪图id（云相册）
	 */
	private long cutPhotoId;

	/**
	 * 拍摄的证件信息
	 */
	private List<Certificate> certificates;

	/**
	 * 获取 用户id
	 * 
	 * @return 用户id
	 */
	public long getUserId() {
		return userId;
	}

	/**
	 * 设置 用户id
	 * 
	 * @param userId
	 *            用户id
	 */
	public void setUserId(long userId) {
		this.userId = userId;
	}

	/**
	 * 获取 相册id（云相册）
	 * 
	 * @return 相册id（云相册）
	 */
	public long getAlbumId() {
		return albumId;
	}

	/**
	 * 设置 相册id（云相册）
	 * 
	 * @param albumId
	 *            相册id（云相册）
	 */
	public void setAlbumId(long albumId) {
		this.albumId = albumId;
	}

	/**
	 * 获取 原图id（云相册）
	 * 
	 * @return 原图id（云相册）
	 */
	public long getPhotoId() {
		return photoId;
	}

	/**
	 * 设置 原图id（云相册）
	 * 
	 * @param photoId
	 *            原图id（云相册）
	 */
	public void setPhotoId(long photoId) {
		this.photoId = photoId;
	}

	/**
	 * 获取 裁剪图id（云相册）
	 * 
	 * @return 裁剪图id（云相册）
	 */
	public long getCutPhotoId() {
		return cutPhotoId;
	}

	/**
	 * 设置 裁剪图id（云相册）
	 * 
	 * @param cutPhotoId
	 *            裁剪图id（云相册）
	 */
	public void setCutPhotoId(long cutPhotoId) {
		this.cutPhotoId = cutPhotoId;
	}

	/**
	 * 获取 拍摄的证件信息
	 * 
	 * @return 拍摄的证件信息
	 */
	public List<Certificate> getCertificates() {
		return certificates;
	}

	/**
	 * 设置 拍摄的证件信息
	 * 
	 * @param certificates
	 *            拍摄的证件信息
	 */
	public void setCertificates(List<Certificate> certificates) {
		this.certificates = certificates;
	}

}
