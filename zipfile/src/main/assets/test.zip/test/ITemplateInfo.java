package com.xingfu.access.pojo.basicdata.template;

/**
 * 证件类型模板信息实体规范
 *
 * @author zhangx
 *
 */
public interface ITemplateInfo {

	/**
	 * 获取 证件类型ID
	 * 
	 * @return 证件类型ID
	 */
	long getCredTypeId();

	/**
	 * 设置 证件类型ID
	 * 
	 * @param credTypeId
	 *            证件类型ID
	 */
	void setCredTypeId(long credTypeId);

	/**
	 * 获取 证件类型名称
	 * 
	 * @return 证件类型名称
	 */
	String getCredTypeName();

	/**
	 * 设置 证件类型名称
	 * 
	 * @param credTypeName
	 *            证件类型名称
	 */
	void setCredTypeName(String credTypeName);

	/**
	 * 获取 证件类型baseId
	 * 
	 * @return 证件类型baseId
	 */
	String getCredTypeBaseId();

	/**
	 * 设置 证件类型baseId
	 * 
	 * @param credTypeBaseId
	 *            证件类型baseId
	 */
	void setCredTypeBaseId(String credTypeBaseId);

	/**
	 * 获取 证件模板url
	 * 
	 * @return 证件模板url
	 */
	String getCertPhotoUrl();

	/**
	 * 设置 证件模板url
	 * 
	 * @param certPhotoUrl
	 *            证件模板url
	 */
	void setCertPhotoUrl(String certPhotoUrl);

	/**
	 * 获取 贴标像模板url
	 * 
	 * @return 贴标像模板url
	 */
	String getTibPhotoUrl();

	/**
	 * 设置 贴标像模板url
	 * 
	 * @param tibPhotoUrl
	 *            贴标像模板url
	 */
	void setTibPhotoUrl(String tibPhotoUrl);

	/**
	 * 获取 回执模板url
	 * 
	 * @return 回执模板url
	 */
	String getReceiptPhotoUrl();

	/**
	 * 设置 回执模板url
	 * 
	 * @param receiptPhotoUrl
	 *            回执模板url
	 */
	void setReceiptPhotoUrl(String receiptPhotoUrl);

}